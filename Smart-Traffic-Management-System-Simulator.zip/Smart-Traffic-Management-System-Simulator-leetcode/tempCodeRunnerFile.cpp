~CongestionMonitor() {
    //     while (head) {
    //         RoadSegment* temp = head;
    //         head = head->next;
    //         delete temp;
    //     }
    // }